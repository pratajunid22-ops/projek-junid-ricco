<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Models\User;
use App\Models\Attendance;
use Carbon\Carbon;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    $user = auth()->user();
    $hariIni = Carbon::today();
    $bulanIni = Carbon::now()->month;
    $tahunIni = Carbon::now()->year;

    if ($user->role === 'admin') {
        // --- STATISTIK ADMIN ---
        // Menghitung total user (selain admin)
        $totalKaryawan = User::where('role', 'user')->count();
        // Menghitung absen hari ini
        $hadirHariIni = Attendance::whereDate('tanggal', $hariIni)->where('status', 'Hadir')->count();
        $izinSakitHariIni = Attendance::whereDate('tanggal', $hariIni)->whereIn('status', ['Izin', 'Sakit'])->count();

        return view('dashboard', compact('totalKaryawan', 'hadirHariIni', 'izinSakitHariIni'));

    } else {
        // --- STATISTIK USER BIASA ---
        // Menghitung total kehadiran khusus user ini di bulan ini
        $hadirBulanIni = Attendance::where('user_id', $user->id)
                                   ->whereMonth('tanggal', $bulanIni)
                                   ->whereYear('tanggal', $tahunIni)
                                   ->where('status', 'Hadir')
                                   ->count();

        return view('dashboard', compact('hadirBulanIni'));
    }
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

use App\Http\Controllers\AttendanceController;

// ... (kode route bawaan breeze biarkan saja)

// Mengelompokkan route yang dilindungi oleh middleware 'auth' (wajib login)
Route::middleware(['auth'])->group(function () {
    // Membuat semua rute CRUD secara otomatis (attendance.index, attendance.store, dll)
    Route::resource('attendances', AttendanceController::class);
});