<?php

namespace App\Http\Controllers;

use App\Models\Attendance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AttendanceController extends Controller
{
    // 1. READ: Menampilkan halaman utama data absensi
    public function index()
    {


    if (auth()->user()->role === 'admin') {
        // Ambil SEMUA data absensi + data USER-nya
        $attendances = Attendance::with('user')->orderBy('tanggal', 'desc')->get();
    } else {
        // Ambil data milik diri sendiri saja
        $attendances = Attendance::where('user_id', auth()->id())->orderBy('tanggal', 'desc')->get();
    }
    
    return view('attendances.index', compact('attendances'));

}
    

    // 2. CREATE: Menampilkan form tambah absen
    public function create()
    {
        return view('attendances.create');
    }

    // 3. STORE: Menyimpan data dari form ke database
    public function store(Request $request)
    {
        // Validasi inputan
        $request->validate([
            'tanggal' => 'required|date',
            'waktu_masuk' => 'required',
            'status' => 'required|in:Hadir,Izin,Sakit',
        ]);

        // Simpan ke database
        Attendance::create([
            'user_id' => Auth::id(), // Otomatis mengisi ID user yang sedang login
            'tanggal' => $request->tanggal,
            'waktu_masuk' => $request->waktu_masuk,
            'status' => $request->status,
        ]);

        return redirect()->route('attendances.index')->with('success', 'Absensi berhasil disimpan!');
    }

    // 4. DELETE: Menghapus data
    public function destroy(Attendance $attendance)
    {
        // Cek apakah yang login adalah Admin ATAU pemilik data itu sendiri
        if (auth()->user()->role === 'admin' || $attendance->user_id === auth()->id()) {
            
            $attendance->delete(); // Eksekusi hapus data
            
            return redirect()->route('attendances.index')->with('success', 'Data berhasil dihapus!');
        }
        
        // Jika bukan admin dan mencoba menghapus data orang lain, gagalkan!
        return redirect()->route('attendances.index')->with('error', 'Anda tidak memiliki izin untuk menghapus data ini.');
    }
 // Halaman Form Edit
public function edit(Attendance $attendance)
{
    // Hanya Admin yang boleh masuk
    if (auth()->user()->role !== 'admin') {
        return redirect()->route('attendances.index')->with('error', 'Hanya Admin yang dapat mengubah data!');
    }

    return view('attendances.edit', compact('attendance'));
}

// Proses Simpan Perubahan
public function update(Request $request, Attendance $attendance)
{
    // Cek keamanan lagi sebelum menyimpan
    if (auth()->user()->role !== 'admin') {
        return redirect()->route('attendances.index')->with('error', 'Izin ditolak!');
    }

    $request->validate([
        'tanggal' => 'required|date',
        'waktu_masuk' => 'required',
        'status' => 'required|in:Hadir,Izin,Sakit',
    ]);

    $attendance->update($request->only(['tanggal', 'waktu_masuk', 'status']));

    return redirect()->route('attendances.index')->with('success', 'Data berhasil diperbarui oleh Admin.');
}
}
