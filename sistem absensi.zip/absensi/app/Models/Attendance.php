<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Attendance extends Model
{
    use HasFactory;

    // Mengizinkan kolom-kolom ini untuk diisi data
    protected $fillable = ['user_id', 'tanggal', 'waktu_masuk', 'status'];

    // Membuat relasi bahwa 1 absensi dimiliki oleh 1 user
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}