<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ 'Dashboard' }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 text-gray-900 text-lg">
                    Halo, <strong>{{ auth()->user()->name }}</strong>! Selamat datang di Sistem Absensi.
                </div>
            </div>

            @if(auth()->user()->role === 'admin')
                <h3 class="text-lg font-bold text-gray-700 mb-4">Ringkasan Hari Ini</h3>
                
                <div class="text-3xl font-bold text-blue-900 mt-2">{{ $totalKaryawan }}</div>
                <div class="text-3xl font-bold text-green-900 mt-2">{{ $hadirHariIni }}</div>
                <div class="text-3xl font-bold text-yellow-900 mt-2">{{ $izinSakitHariIni }}</div>
            
            @else
                <h3 class="text-lg font-bold text-gray-700 mb-4">Statistik Absensi Anda</h3>
                
                <div>
    <p class="text-green-800 font-bold text-lg">Catatan Bulan Ini</p>
    <p class="text-green-600 text-sm">
        Anda telah hadir sebanyak <strong>{{ $hadirBulanIni }} hari</strong> bulan ini. Pertahankan kerajinan Anda!
    </p>
</div>
            @endif

        </div>
    </div>
</x-app-layout>
