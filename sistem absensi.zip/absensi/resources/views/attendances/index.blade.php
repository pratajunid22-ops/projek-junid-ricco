<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Data Absensi
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            @if(session('success'))
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline">{{ session('success') }}</span>
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    
                    <div class="mb-4">
                        <a href="{{ route('attendances.create') }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            + Tambah Absen Baru
                        </a>
                    </div>

<table class="min-w-full bg-white border">
    <thead>
        <tr class="bg-gray-100 border-b">
            @if(auth()->user()->role === 'admin')
                <th class="text-left py-3 px-4 uppercase font-semibold text-sm text-blue-600">Nama Karyawan</th>
            @endif
            
            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Tanggal</th>
            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Waktu Masuk</th>
            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Status</th>
            <th class="text-left py-3 px-4 uppercase font-semibold text-sm">Aksi</th>
        </tr>
    </thead>
    <tbody>
        @forelse($attendances as $absen)
        <tr class="border-b hover:bg-gray-50">
            @if(auth()->user()->role === 'admin')
                <td class="py-3 px-4 font-bold text-gray-800">{{ $absen->user->name }}</td>
            @endif
            
            <td class="py-3 px-4">{{ $absen->tanggal }}</td>
            <td class="py-3 px-4">{{ $absen->waktu_masuk }}</td>
            <td class="py-3 px-4">
                <span class="px-2 py-1 text-sm rounded-full 
                    {{ $absen->status == 'Hadir' ? 'bg-green-200 text-green-800' : ($absen->status == 'Izin' ? 'bg-yellow-200 text-yellow-800' : 'bg-red-200 text-red-800') }}">
                    {{ $absen->status }}
                </span>
                <td class="py-3 px-4">
    <div class="flex items-center space-x-4">
        
        @if(auth()->user()->role === 'admin')
            <a href="{{ route('attendances.edit', $absen->id) }}" class="flex items-center text-indigo-600 hover:text-indigo-900">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                </svg>
                <span>Edit</span>
            </a>
            <span class="text-gray-300">|</span>
        @endif

        <form action="{{ route('attendances.destroy', $absen->id) }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus?');">
            @csrf
            @method('DELETE')
            <button type="submit" class="text-red-600 hover:text-red-900">
                Hapus
            </button>
        </form>

    </div>
</td>
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="5" class="py-4 text-center text-gray-500">Belum ada data absensi.</td>
        </tr>
        @endforelse
    </tbody>
</table>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>