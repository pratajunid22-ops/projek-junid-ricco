<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Ubah Data Absensi
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    
                    <form action="{{ route('attendances.update', $attendance->id) }}" method="POST" class="max-w-lg">
                        @csrf
                        @method('PUT') <div class="mb-4">
                            <label class="block text-sm font-bold mb-2">Tanggal</label>
                            <input type="date" name="tanggal" value="{{ $attendance->tanggal }}" required class="border rounded w-full py-2 px-3">
                        </div>

                        <div class="mb-4">
                            <label class="block text-sm font-bold mb-2">Waktu Masuk</label>
                            <input type="time" name="waktu_masuk" value="{{ $attendance->waktu_masuk }}" required class="border rounded w-full py-2 px-3">
                        </div>

                        <div class="mb-6">
                            <label class="block text-sm font-bold mb-2">Status</label>
                            <select name="status" required class="border rounded w-full py-2 px-3">
                                <option value="Hadir" {{ $attendance->status == 'Hadir' ? 'selected' : '' }}>Hadir</option>
                                <option value="Izin" {{ $attendance->status == 'Izin' ? 'selected' : '' }}>Izin</option>
                                <option value="Sakit" {{ $attendance->status == 'Sakit' ? 'selected' : '' }}>Sakit</option>
                            </select>
                        </div>

                        <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Simpan Perubahan
                        </button>
                        
                        <a href="{{ route('attendances.index') }}" class="ml-4 text-gray-600 hover:underline">Batal</a>
                    </form>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>