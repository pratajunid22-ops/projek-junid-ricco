<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e('Dashboard'); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 text-gray-900 text-lg">
                    Halo, <strong><?php echo e(auth()->user()->name); ?></strong>! Selamat datang di Sistem Absensi.
                </div>
            </div>

            <?php if(auth()->user()->role === 'admin'): ?>
                <h3 class="text-lg font-bold text-gray-700 mb-4">Ringkasan Hari Ini</h3>
                
                <div class="text-3xl font-bold text-blue-900 mt-2"><?php echo e($totalKaryawan); ?></div>
                <div class="text-3xl font-bold text-green-900 mt-2"><?php echo e($hadirHariIni); ?></div>
                <div class="text-3xl font-bold text-yellow-900 mt-2"><?php echo e($izinSakitHariIni); ?></div>
            
            <?php else: ?>
                <h3 class="text-lg font-bold text-gray-700 mb-4">Statistik Absensi Anda</h3>
                
                <div>
    <p class="text-green-800 font-bold text-lg">Catatan Bulan Ini</p>
    <p class="text-green-600 text-sm">
        Anda telah hadir sebanyak <strong><?php echo e($hadirBulanIni); ?> hari</strong> bulan ini. Pertahankan kerajinan Anda!
    </p>
</div>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\absensi\resources\views/dashboard.blade.php ENDPATH**/ ?>