<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddDepartemenIdToUsersTable extends Migration
{
    public function up(): void
{
    Schema::table('users', function (Blueprint $table) {
        // Menambahkan departemen_id. 
        // nullable() = boleh kosong (untuk user lama yang belum punya departemen)
        // nullOnDelete() = jika departemen dihapus, data user tetap aman (tidak ikut terhapus), hanya status departemennya jadi kosong.
        $table->foreignId('departemen_id')->nullable()->after('role')
              ->constrained('departemens')->nullOnDelete();
    });
}

public function down(): void
{
    Schema::table('users', function (Blueprint $table) {
        $table->dropForeign(['departemen_id']);
        $table->dropColumn('departemen_id');
    });
}
}