<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Data Departemen</h2>
    </x-slot>

    <div class="py-12 max-w-7xl mx-auto sm:px-6 lg:px-8">
        @if(session('success'))
            <div class="mb-4 bg-green-100 text-green-700 p-3 rounded">{{ session('success') }}</div>
        @endif
        
        <div class="bg-white shadow-sm sm:rounded-lg p-6">
            <a href="{{ route('departemens.create') }}" class="bg-blue-500 text-white px-4 py-2 rounded mb-4 inline-block">+ Tambah Departemen</a>
            
            <table class="min-w-full bg-white border mt-4">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="py-2 px-4 border-b text-left">Nama Departemen</th>
                        <th class="py-2 px-4 border-b text-left">Keterangan</th>
                        <th class="py-2 px-4 border-b text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($departemens as $dept)
                    <tr class="border-b">
                        <td class="py-2 px-4">{{ $dept->nama_departemen }}</td>
                        <td class="py-2 px-4">{{ $dept->keterangan ?? '-' }}</td>
                        <td class="py-2 px-4 text-center">
                            <a href="{{ route('departemens.edit', $dept->id) }}" class="text-blue-500 mr-2">Edit</a>
                            <form action="{{ route('departemens.destroy', $dept->id) }}" method="POST" class="inline" onsubmit="return confirm('Hapus departemen ini?');">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-red-500">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</x-app-layout>