<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Ubah Departemen</h2>
    </x-slot>
    <div class="py-12 max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white shadow-sm sm:rounded-lg p-6">
            <form action="{{ route('departemens.update', $departemen->id) }}" method="POST">
                @csrf @method('PUT')
                <div class="mb-4">
                    <label class="block font-bold mb-1">Nama Departemen</label>
                    <input type="text" name="nama_departemen" value="{{ $departemen->nama_departemen }}" required class="w-full border rounded p-2">
                </div>
                <div class="mb-4">
                    <label class="block font-bold mb-1">Keterangan</label>
                    <textarea name="keterangan" class="w-full border rounded p-2">{{ $departemen->keterangan }}</textarea>
                </div>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Update</button>
                <a href="{{ route('departemens.index') }}" class="ml-2 text-gray-600">Batal</a>
            </form>
        </div>
    </div>
</x-app-layout>