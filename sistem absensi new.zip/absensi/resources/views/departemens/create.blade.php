<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Tambah Departemen</h2>
    </x-slot>
    <div class="py-12 max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white shadow-sm sm:rounded-lg p-6">
            <form action="{{ route('departemens.store') }}" method="POST">
                @csrf
                <div class="mb-4">
                    <label class="block font-bold mb-1">Nama Departemen</label>
                    <input type="text" name="nama_departemen" required class="w-full border rounded p-2" placeholder="Cth: Kearsipan, IT, HRD...">
                </div>
                <div class="mb-4">
                    <label class="block font-bold mb-1">Keterangan</label>
                    <textarea name="keterangan" class="w-full border rounded p-2"></textarea>
                </div>
                <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded">Simpan</button>
                <a href="{{ route('departemens.index') }}" class="ml-2 text-gray-600">Batal</a>
            </form>
        </div>
    </div>
</x-app-layout>