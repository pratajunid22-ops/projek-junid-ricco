<?php

namespace App\Http\Controllers;

use App\Models\Departemen;
use Illuminate\Http\Request;

class DepartemenController extends Controller
{
    // Fungsi bantuan untuk mengecek apakah user adalah admin
    private function cekAdmin() {
        if (auth()->user()->role !== 'admin') {
            abort(403, 'Hanya Admin yang dapat mengakses halaman ini.');
        }
    }

    public function index()
    {
        $this->cekAdmin();
        $departemens = Departemen::orderBy('nama_departemen', 'asc')->get();
        return view('departemens.index', compact('departemens'));
    }

    public function create()
    {
        $this->cekAdmin();
        return view('departemens.create');
    }

    public function store(Request $request)
    {
        $this->cekAdmin();
        $request->validate(['nama_departemen' => 'required|string|max:255']);
        Departemen::create($request->all());
        return redirect()->route('departemens.index')->with('success', 'Departemen berhasil ditambahkan!');
    }

    public function edit(Departemen $departemen)
    {
        $this->cekAdmin();
        return view('departemens.edit', compact('departemen'));
    }

    public function update(Request $request, Departemen $departemen)
    {
        $this->cekAdmin();
        $request->validate(['nama_departemen' => 'required|string|max:255']);
        $departemen->update($request->all());
        return redirect()->route('departemens.index')->with('success', 'Data berhasil diubah!');
    }

    public function destroy(Departemen $departemen)
    {
        $this->cekAdmin();
        $departemen->delete();
        return redirect()->route('departemens.index')->with('success', 'Data berhasil dihapus!');
    }
}