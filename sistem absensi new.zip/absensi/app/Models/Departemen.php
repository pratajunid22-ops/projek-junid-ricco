<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Departemen extends Model
{
    use HasFactory;

    // 1. Mengizinkan kolom ini untuk diisi data
    protected $fillable = [
        'nama_departemen', 
        'keterangan'
    ];

    // 2. Fungsi Relasi: Memberitahu sistem bahwa 1 Departemen memiliki banyak User (karyawan)
    public function users()
    {
        return $this->hasMany(User::class);
    }
}